#!/bin/bash
# bg.sh OUT.jsonl jobs...   -> runs batch in background, log in OUT.log
cd $HOME/work && source $HOME/venv/bin/activate && export PYTHONPATH=$PWD/src MUJOCO_GL=disable
out=$1; shift
nohup setsid python tools/batch.py $out "$@" > ${out%.jsonl}.log 2>&1 < /dev/null &
echo started $!
