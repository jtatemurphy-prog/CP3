"""mk.py base.json out.json gap|none 'program-json'|keep"""
import json, sys
d = json.load(open(sys.argv[1]))
g = sys.argv[3]
if g == "none": d.pop("start_gap_mm", None)
else: d["start_gap_mm"] = float(g)
if sys.argv[4] != "keep": d["motor_program"] = json.loads(sys.argv[4])
d["name"] = sys.argv[2].split("/")[-1][:-5]
json.dump(d, open(sys.argv[2], "w"), indent=1)
