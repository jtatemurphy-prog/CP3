import json, sys
def load(p): return json.load(open(p))
def save(d, p, name=None):
    d["name"] = name or p.split("/")[-1][:-5]; json.dump(d, open(p, "w"), indent=1)
def strip(d, names):
    names = set(names)
    d['parts'] = [p for p in d['parts'] if p['name'] not in names]
    d['connections'] = [c for c in d['connections'] if c['child'] not in names and c['parent'] not in names]
    d['gear_meshes'] = [m for m in d['gear_meshes'] if m['gear_a'] not in names and m['gear_b'] not in names]
