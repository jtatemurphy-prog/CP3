# Population results (plain runs)

| design | steps | rope | ramp | bridge | passes | time |
|---|---|---|---|---|---|---|
| C1 |  | stuck 0.78 | PASS 24.40s |  | 1 | 24.40 |
| C1g150 | stuck 0.32 |  |  |  | 0 | 0.00 |
| D1 | stuck 0.09 | stuck 0.22 | wall-clock limit 0.34 | touched chasm floor (motb) 0.81 | 0 | 0.00 |
| F1 |  | stuck 0.22 | wall-clock limit 0.37 | PASS 1.50s | 1 | 1.50 |
| G1 | stuck 0.14 | stuck 0.29 | stuck 0.32 | PASS 1.97s | 1 | 1.97 |
| H1 | stuck 0.15 | stuck 0.80 | stuck 0.28 | touched chasm floor (motr) 0.72 | 0 | 0.00 |
| K1 | stuck 0.23 |  |  | touched chasm floor (motr) 0.71 | 0 | 0.00 |
| K2 |  | broke (axfL, gfL, wfL) 0.74 |  |  | 0 | 0.00 |
| K3 | stuck 0.49 |  |  | touched chasm floor (motr) 0.56 | 0 | 0.00 |
| N0b |  | stuck 0.21 | stuck 0.14 |  | 0 | 0.00 |
| N2 | stuck 0.23 | broke (axfL, gfL, spfL, wfL) 0.56 | PASS 25.49s | touched chasm floor (motfR) 0.66 | 1 | 25.49 |
| N2X | stuck 0.23 | broke (axfL, gfL, spfL, wfL) 0.74 | PASS 6.67s | touched chasm floor (motfR) 0.57 | 1 | 6.67 |
| P1X | stuck 0.23 | stuck 0.16 | PASS 6.43s | touched chasm floor (motfR) 0.61 | 1 | 6.43 |
| P2 | stuck 0.23 | broke (axfR, gfR, spfR, wfR) 0.43 | PASS 24.12s | touched chasm floor (motfR) 0.74 | 1 | 24.12 |
| P2X | stuck 0.23 | broke (axfR, gfR, spfR, wfR) 0.43 | PASS 6.19s | touched chasm floor (motfR) 0.56 | 1 | 6.19 |
| S3_000 | stuck 0.15 |  |  | left_lane 0.96 | 0 | 0.00 |
| S3_001 | stuck 0.23 |  |  | touched chasm floor (motr) 0.60 | 0 | 0.00 |
| S3_002 | stuck 0.23 |  |  | touched chasm floor (motf) 0.32 | 0 | 0.00 |
| S3_003 | stuck 0.23 |  |  | touched chasm floor (motf) 0.34 | 0 | 0.00 |
| S3_004 | stuck 0.23 |  |  | PASS 2.21s | 1 | 2.21 |
| S3_007 | stuck 0.23 |  |  | PASS 2.75s | 1 | 2.75 |
| S3_008 | stuck 0.23 |  |  | touched chasm floor (motf) 0.32 | 0 | 0.00 |
| S3_009 | stuck 0.23 |  |  | touched chasm floor (motfR) 0.77 | 0 | 0.00 |
| S3_010 | stuck 0.23 |  |  | touched chasm floor (motfR) 0.68 | 0 | 0.00 |
| S3_012 | stuck 0.23 |  |  | PASS 2.21s | 1 | 2.21 |
| S3_013 | stuck 0.23 |  |  | touched chasm floor (motf) 0.25 | 0 | 0.00 |
| S3_019 | stuck 0.23 |  |  | touched chasm floor (motf) 0.28 | 0 | 0.00 |
| S3_022 | stuck 0.15 |  |  | PASS 1.33s | 1 | 1.33 |
| S3_027 | stuck 0.23 |  |  | touched chasm floor (motfR) 0.74 | 0 | 0.00 |
| S3_028 |  |  |  | PASS 2.65s | 1 | 2.65 |
