"""regen.py out.json '{overrides}'  -> U12 recipe + z4c transform + G0 settings (gap 0, Q10 program)"""
import json, sys, os
sys.path.insert(0, os.path.expanduser("~/work/agent_gen")); sys.path.insert(0, os.path.expanduser("~/work/src"))
os.chdir(os.path.expanduser("~/work/agent_gen"))
import gN, z4c
REC = dict(motor="58121c01", drive="ff", chain=True, spz=16, helper=True, rope_mode="classic", rope_wheel="55982c01", xR=-56,
           bat_x=16, bat_y=8, rx_y=-40, rb_drive=True, rb_side="L", mg=8, zx_off=64, wheel_y=18.2, hz=8, hy=22, longseg=True)
kw = dict(REC, **(json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}))
extra = {k: kw.pop(k) for k in list(kw) if k in ("gap", "program", "noz4c")}
out = os.path.abspath(os.path.join(os.path.expanduser("~/work"), sys.argv[1]))
d = gN.build(name=os.path.basename(out)[:-5], **kw)
p = d.save(out)
dd = json.load(open(p))
if not extra.get("noz4c"): dd = z4c.z4c(dd, os.path.basename(out)[:-5])
dd["motor_program"] = extra.get("program", [{"t": 0, "motor": "all", "level": 6}, {"t": 0.7, "motor": "all", "level": 7}])
dd["start_gap_mm"] = float(extra.get("gap", 0))
json.dump(dd, open(out, "w"), indent=1)
print("wrote", out)
