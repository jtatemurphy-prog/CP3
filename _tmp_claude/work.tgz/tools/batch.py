"""batch.py OUT.jsonl design:bench:nudge ...   (runs up to NJ=4 sims in parallel, no video)"""
import json, os, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
H = os.path.expanduser("~/work")
sys.path.insert(0, os.path.join(H, "src"))
import importlib.machinery, types
L = importlib.machinery.SourceFileLoader("brick_mod", os.path.join(H, "brick"))
b = types.ModuleType(L.name); b.__file__ = os.path.join(H, "brick"); L.exec_module(b)
NUD = {"plain": {}, "off": {"LEGO_BENCH_START_DY": "0.001"}, "late": {"LEGO_BENCH_SETTLE_DELTA": "0.05"}}
out = sys.argv[1]
jobs = [a.split(":") for a in sys.argv[2:]]
def one(j):
    path, bench, nud = j
    path = os.path.abspath(path)
    tag = f"{os.path.basename(path)[:-5]}_{bench}_{nud}"
    d = os.path.join(H, "_sims", tag); os.makedirs(d, exist_ok=True)
    cmd = [sys.executable, os.path.join(H, "simulator", "run_csim.py"), "--design", path, "--obstacle", bench,
           "--level", "1", "--out", os.path.join(d, "result.json")]
    if os.environ.get("REC"): cmd += ["--record", os.path.join(d, "record.json")]
    if nud.startswith("dy"): ne = {"LEGO_BENCH_START_DY": nud[2:]}
    elif nud.startswith("dl"): ne = {"LEGO_BENCH_SETTLE_DELTA": nud[2:]}
    else: ne = NUD[nud]
    e = dict(os.environ, **ne, PYTHONPATH=os.path.join(H, "src"))
    t0 = time.time()
    rp = os.path.join(d, "result.json")
    if os.path.exists(rp): os.remove(rp)
    with open(os.path.join(d, "sim.log"), "w") as f:
        subprocess.run(cmd, cwd=os.path.join(H, "simulator"), env=e, stdout=f, stderr=subprocess.STDOUT, timeout=1800)
    if not os.path.exists(rp):
        r = {"crossed": False, "failure": "NO RESULT " + open(os.path.join(d, "sim.log")).read()[-300:]}
    else:
        r = json.load(open(rp))
    s = {"tag": tag, "pass": bool(r.get("crossed")), "t": r.get("time_s"), "fail": r.get("failure"),
         "prog": r.get("max_progress"), "wall": round(time.time() - t0)}
    print(json.dumps(s), flush=True)
    with open(out, "a") as f: f.write(json.dumps(s) + "\n")
    return s
with ThreadPoolExecutor(int(os.environ.get("NJ", 4))) as ex:
    list(ex.map(one, jobs))
